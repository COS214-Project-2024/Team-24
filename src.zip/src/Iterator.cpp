#include "Iterator.h"

Iterator::Iterator(RoadNetwork* network)
{
    roadNetwork = network;
}

Road* Iterator::getRoad()
{
    if(currRoad)
    {
        return currRoad;
    }
}
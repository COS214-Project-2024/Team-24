#include "TaxStrategy.h"

// Since all methods are either pure virtual or defined in the header,
// we don't need any implementation here.
// This file can be empty or removed.
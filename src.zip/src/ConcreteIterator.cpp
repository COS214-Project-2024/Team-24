#include "ConcreteIterator.h"


void ConcreteIterator::first()
{
    traversedRoads.clear();
    
}

void ConcreteIterator::next()
{
    
}

Road* ConcreteIterator::current()
{
    return currRoad;
}

Road* ConcreteIterator::getRoad()
{
    return currRoad;
}

bool ConcreteIterator::isDone()
{
    return  traversedRoads.size() == roadNetwork->roads.size();
}
